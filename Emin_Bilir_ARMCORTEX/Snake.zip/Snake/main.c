//*****************************************************************************
	// hello.c - Simple hello world example.
	//
	// Maciej Kucia July 2013
	//
	// This is part of revision 1.0 of the EK-LM4F232 Firmware Package.
	//*****************************************************************************

	#include <stdint.h>
	#include <stdbool.h>
	#include "inc/hw_memmap.h"
	#include "driverlib/fpu.h"
	#include "driverlib/sysctl.h"
	#include "driverlib/rom.h"
	#include "driverlib/pin_map.h"
	#include "driverlib/uart.h"
#include "grlib/grlib.h"
	#include "drivers/ili9341_240x320x262K.h"
	#include "utils/uartstdio.h"
	#include "driverlib/gpio.h"
#define GPIO_PINS_ALL GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7

	//*****************************************************************************
	//
	// TI logo in array form (1 bit per pixel)
	//
	//*****************************************************************************
	const unsigned char TI_logo[(16*2)+5] = {
	IMAGE_FMT_1BPP_UNCOMP, 16,0, 16,0,
	0x0f,0xff,0x0f,0xff,0x0f,0xf3,0x0f,0xfa,0x0f,0x8f,0x0f,0x89,0x81,0x99,0x81,0x19,0x03,0x09,0x07,0x89,0x07,0xdf,0x3f,0xee,0x7f,0xf0,0xff,0xf8,0xff,0xf9,0xff,0xfb};
	//	1,1,1,1,0,0,0,0, 1,1,1,1,1,1,1,1,
	//	1,1,1,1,0,0,0,0, 1,1,1,1,1,1,1,1,
	//	1,1,1,1,0,0,0,0, 1,1,0,0,1,1,1,1,
	//	1,1,1,1,0,0,0,0, 0,1,0,1,1,1,1,1,
	//	1,1,1,1,0,0,0,0, 1,1,1,1,0,0,0,1,
	//	1,1,1,1,0,0,0,0, 1,0,0,1,0,0,0,1,
	//	1,0,0,0,0,0,0,1, 1,0,0,1,1,0,0,1,
	//	1,0,0,0,0,0,0,1, 1,0,0,1,1,0,0,0,
	//	1,1,0,0,0,0,0,0, 1,0,0,1,0,0,0,0,
	//	1,1,1,0,0,0,0,0, 1,0,0,1,0,0,0,1,
	//	1,1,1,0,0,0,0,0, 1,1,1,1,1,0,1,1,
	//	1,1,1,1,1,1,0,0, 0,1,1,1,0,1,1,1,
	//	1,1,1,1,1,1,1,0, 0,0,0,0,1,1,1,1,
	//	1,1,1,1,1,1,1,1, 0,0,0,1,1,1,1,1,
	//	1,1,1,1,1,1,1,1, 1,0,0,1,1,1,1,1,
	//	1,1,1,1,1,1,1,1, 1,1,0,1,1,1,1,1
	//*****************************************************************************
	//
	// Print some text to the display.
	//
	//***********************************************
	int
	main(void)
	{
	SysCtlPeripheralEnable (SYSCTL_PERIPH_GPIOB);
	SysCtlPeripheralEnable (SYSCTL_PERIPH_GPIOE);
	SysCtlPeripheralEnable (SYSCTL_PERIPH_GPIOH);
	SysCtlPeripheralEnable (SYSCTL_PERIPH_GPIOK);
	GPIOPinTypeGPIOInput(GPIO_PORTK_BASE, GPIO_PINS_ALL);
	GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, GPIO_PINS_ALL);
	GPIOPinTypeGPIOInput(GPIO_PORTH_AHB_BASE, GPIO_PIN_2);
	GPIOPinTypeGPIOInput(GPIO_PORTE_BASE, GPIO_PINS_ALL);
	tContext sContext;
	tRectangle sRect;
	//
	// Enable lazy stacking for interrupt handlers. This allows floating-point
	// instructions to be used within interrupt handlers, but at the expense of
	// extra stack usage.
	//
	ROM_FPULazyStackingEnable();
	//
	// Set the clocking to run directly from the crystal.
	//
	ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ |SYSCTL_OSC_MAIN);

	//
	// Initialize the display driver.
	//
	ILI9341_240x320x262K_Init();
	//
	// Initialize the graphics context.
	//
	GrContextInit(&sContext, &g_sILI9341_240x320x262K);
	//
	// Print some text
	//
	GrContextFontSet(&sContext, g_psFontCm12);
//	GrStringDrawCentered(&sContext, "Emin", -1,GrContextDpyWidthGet(&sContext) / 2,(GrContextDpyHeightGet(&sContext) / 2),0);
//
//	GrContextForegroundSet(&sContext, ClrCrimson);
//
//	GrContextFontSet(&sContext, g_psFontCm20b);
//	GrStringDrawCentered(&sContext, "Bilir", -1,GrContextDpyWidthGet(&sContext) / 2,60 + (GrContextDpyHeightGet(&sContext) / 2),0);
//
//	//
//	// Draw TI logo
//	//
//	sRect.i16XMin = 0;
//	sRect.i16YMin = 220;
//	sRect.i16XMax = 319;
//	sRect.i16YMax = 239;
//	GrContextBackgroundSet(&sContext, ClrWhite);
//	GrContextForegroundSet(&sContext, ClrRed);
//	GrRectFill(&sContext, &sRect);
//	GrImageDraw(&sContext, TI_logo, 200, 222);
//
//	GrContextForegroundSet(&sContext, ClrWhite);
//	GrContextFontSet(&sContext, g_psFontFixed6x8);
//	GrStringDraw(&sContext, "Fenerbah�e", -1,218,222,0);
//	GrStringDraw(&sContext, "Spor Kul�b�", -1,218,230,0);
//	//
//	// Flush any cached drawing operations.
//	//
//	GrFlush(&sContext);

	//
	// We are finished. Hang around doing nothing.
	//
	unsigned long ii = 1;

	int controlright=0;
	int controlleft=0;
	int controldown=0;
	int controlup=0;
	int controlpress=0;
	int xmin,xmax,ymin,ymax;

	sRect.i16XMin = 20;
	sRect.i16YMin = 20;
	sRect.i16XMax = 50;
	sRect.i16YMax = 50;
	GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
	GrContextForegroundSet(&sContext, ClrGreen);
	GrRectFill(&sContext, &sRect);
	xmin=5;xmax=35;
	ymin=5;ymax=35;
	bool control=false;
	int xsnake;
	int ysnake;
	int score;
while(1){
	if(!control)
			{
				control=!control;
				xsnake= ((rand()%20)*12)+10;
				ysnake= ((rand()%20)*8)+40;
				GrContextForegroundSet(&sContext, ClrRed);
				GrCircleFill(&sContext, jPosX, jPosY, 5);
			}

			if((xsnake >= sRect.i16XMin && xsnake <= sRect.i16XMax) && (ysnake >= sRect.i16YMin && ysnake <=sRect.i16YMax ))
			{
				control=!control;
				GrContextForegroundSet(&sContext, ClrWhite);
				GrCircleFill(&sContext, xsnake, ysnake, 5);
				xsnake=0;
				ysnake=0;
				GrContextBackgroundSet(&sContext, ClrWhite);
				GrContextForegroundSet(&sContext, ClrGreen);
				GrRectFill(&sContext, &sRect);
				GrContextForegroundSet(&sContext, ClrWhite);
				GrContextFontSet(&sContext, g_psFontFixed6x8);
				score+=1;
				if (score == 10)
				{
					GrContextForegroundSet(&sContext, ClrPurple);
					GrContextFontSet(&sContext, &g_sFontCm16i);
					GrStringDrawCentered(&sContext, "kazandiniz!", -1,120,160,0);
					for(;;)
					{
					}
				}

			}

	controlright = GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_4);//if push right joystick
	controlleft = GPIOPinRead(GPIO_PORTK_BASE,GPIO_PIN_7);//if push left joystick
	controldown = GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_5);//if push down joystick
	controlup = GPIOPinRead(GPIO_PORTB_BASE,GPIO_PIN_0);//if push up joystick
	controlpress = GPIOPinRead(GPIO_PORTH_AHB_BASE,GPIO_PIN_2);//if push push joystick
	
	if(controlright==0)//if for event right joystick
	{
		//GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
	GrContextForegroundSet(&sContext, ClrWhite);
	GrRectFill(&sContext, &sRect);
	xmin=xmin+1;
	xmax=xmax+1;
	sRect.i16XMin = xmin;
	sRect.i16XMax = xmax;
	sRect.i16YMin = ymin;
	sRect.i16YMax = ymax;
			if(xmin==289&&xmax==319)
			{//if sentence for the end of the LCD ,to start from begininng
				sRect.i16XMin = 0;sRect.i16YMin = ymin;
				sRect.i16XMax = 30;sRect.i16YMax = ymax;	GrContextBackgroundSet(&sContext, ClrWhite);	GrContextForegroundSet(&sContext, ClrGreen);GrRectFill(&sContext, &sRect);continue;
			}
	//GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
	GrContextForegroundSet(&sContext, ClrGreen);
	GrRectFill(&sContext, &sRect);

	}
	else if(controlleft==0)//if push left joystick
	{
		GrContextForegroundSet(&sContext, ClrWhite);
		GrRectFill(&sContext, &sRect);
		xmin=xmin-1;
		xmax=xmax-1;
		sRect.i16XMin = xmin;
		sRect.i16XMax = xmax;
		sRect.i16YMin = ymin;
		sRect.i16YMax = ymax;
		if(xmin==0&&xmax==30)
			{//if sentence for the end of the LCD ,to start from begininng
					sRect.i16XMin = 289;sRect.i16YMin = ymin;
					sRect.i16XMax = 319;sRect.i16YMax = ymax;GrContextBackgroundSet(&sContext, ClrWhite);	GrContextForegroundSet(&sContext, ClrGreen);GrRectFill(&sContext, &sRect);continue;
			}
	GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
	GrContextForegroundSet(&sContext, ClrGreen);
	GrRectFill(&sContext, &sRect);
	}
	else if(controldown==0)//if for down event joystick
	{
		GrContextForegroundSet(&sContext, ClrWhite);
		GrRectFill(&sContext, &sRect);
		ymin=ymin+1;
		ymax=ymax+1;
		sRect.i16XMin = xmin;
		sRect.i16XMax = xmax;
		sRect.i16YMin =ymin ;
		sRect.i16YMax =ymax;
				if(ymin==209&&ymax==239)
				{//if sentence for the end of the LCD ,to start from begininng
					sRect.i16XMin = xmin;sRect.i16YMin =0;
					sRect.i16XMax = xmax;sRect.i16YMax =30;	GrContextBackgroundSet(&sContext, ClrWhite);	GrContextForegroundSet(&sContext, ClrGreen);GrRectFill(&sContext, &sRect);continue;
				}
		GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
		GrContextForegroundSet(&sContext, ClrGreen);
		GrRectFill(&sContext, &sRect);

	}
	else if(controlup==0)//if for up event joystick;
	{
		GrContextForegroundSet(&sContext, ClrWhite);
		GrRectFill(&sContext, &sRect);
		ymin=ymin-1;
		ymax=ymax-1;
		sRect.i16XMin = xmin;
		sRect.i16XMax = xmax;
		sRect.i16YMin =ymin ;
		sRect.i16YMax =ymax;
				if(ymin==0&&ymax==30)
				{//if sentence for the end of the LCD ,to start from begininng
					sRect.i16XMin = xmin;sRect.i16YMin =209;
					sRect.i16XMax = xmax;sRect.i16YMax =239;	GrContextBackgroundSet(&sContext, ClrWhite);	GrContextForegroundSet(&sContext, ClrGreen);GrRectFill(&sContext, &sRect);continue;
				}
		GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
		GrContextForegroundSet(&sContext, ClrGreen);
		GrRectFill(&sContext, &sRect);

	}
	else if(controlpress==0)//if for event pressing joystick
	{
		sRect.i16XMin = xmin;
		sRect.i16XMax = xmax;
		sRect.i16YMin =ymin ;
		sRect.i16YMax =ymax;
		GrContextBackgroundSet(&sContext, ClrWhite);//to draw the screen as a white color;
		GrContextForegroundSet(&sContext, ClrGreen);
		GrRectFill(&sContext, &sRect);
		ROM_SysCtlDelay(ROM_SysCtlClockGet()/20);//delay to able to see the color changes;
		ii=ii+0.01;
		GrContextForegroundSet(&sContext, ii);
		GrRectFill(&sContext, &sRect);
		ROM_SysCtlDelay(ROM_SysCtlClockGet()/10);//delay to able to see the color changes;
		GrContextForegroundSet(&sContext, ClrGreen);
		GrRectFill(&sContext, &sRect);


	}

//	ROM_SysCtlDelay(ROM_SysCtlClockGet()/20);//delay to able to see the changes on the location;

	}
}
